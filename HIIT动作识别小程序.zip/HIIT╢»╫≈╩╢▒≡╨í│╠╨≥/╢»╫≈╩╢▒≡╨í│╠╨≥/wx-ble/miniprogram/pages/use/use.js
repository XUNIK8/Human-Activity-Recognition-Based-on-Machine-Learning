// pages/use/use.js
const app = getApp()
const myaudioStart = wx.createInnerAudioContext();
const myaudioEnd = wx.createInnerAudioContext();
const myaudioAction0 = wx.createInnerAudioContext();
const myaudioAction1 = wx.createInnerAudioContext();
const myaudioAction2 = wx.createInnerAudioContext();
const myaudioAction3 = wx.createInnerAudioContext();
const myaudioAction4 = wx.createInnerAudioContext();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    text:['徒手侧平举\n','前后交叉小跑\n','开合跳\n','半蹲\n'],
    text1:'\n首先请注意：在返回上一页面前，务必先点击“终止识别”按钮以结束进程。\n\n本页面功能用于使用者进行动作识别和计数。\n 1. 请使用者打开手机声音，将有语音播报。\n 2. 使用时请左手握手机、机背贴掌心、机身正置。 \n 3. 点击按钮后，下方将出现60s倒计时，使用者在语音开始后按照图示动作随意进行任意动作。\n 4. 页面上方将实时显示使用者正在进行的动作，同时定时对当前动作进行语音播报。\n 5. 倒计时结束后将自动终止识别，用户也可选择手动终止。终止时伴有语音提示，并可同时通过动作识别方法和波峰计数方法计算出 终止识别前用户的实际动作数和小程序识别到的标准动作数，并在动图下方给予显示。 \n 6.终止识别后，再次点击开始识别按钮时，将重置所有数据。',

    num_Method1:[0,0,0,0],
    num_Method2:[0,0,0,0],
    value: 0,
    displayValue:0,
    accXs: [],
    accYs: [],
    accZs: [],
    rgXs: [],
    rgYs: [],
    rgZs: [],

    accYsAll: [],
    activity:[],

    timeSs: [],
    timer : '',
    timer1:'',
    timer2:'',
    startTime: 0,
    action:'',
    value1:1500,
    show:true
  },

  showPopup() {
    this.setData({ show: true });
  },
  onClose() {
    this.setData({ show: false });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onShow:function(){

myaudioStart.src = 'cloud://test-krasj.7465-test-krasj-1301103624/actionvoice/start.mp3'
    myaudioEnd.src='cloud://test-krasj.7465-test-krasj-1301103624/actionvoice/end.mp3'
    myaudioAction0.src = 'cloud://test-krasj.7465-test-krasj-1301103624/actionvoice/0.mp3'
    myaudioAction1.src = 'cloud://test-krasj.7465-test-krasj-1301103624/actionvoice/1.mp3'
    myaudioAction2.src = 'cloud://test-krasj.7465-test-krasj-1301103624/actionvoice/2.mp3'
    myaudioAction3.src = 'cloud://test-krasj.7465-test-krasj-1301103624/actionvoice/3.mp3'
    myaudioAction4.src = 'cloud://test-krasj.7465-test-krasj-1301103624/actionvoice/4.mp3'
  },
  onLoad: function (options) {
    console.log("获取加速度计数据");
    wx.startAccelerometer({
      interval: 'game',
      success: res => { console.log("调用成功"); },
      fail: res => { console.log(res) }
    });
    wx.startGyroscope({
      interval: 'game',
      success: res => { console.log("调用成功"); },
      fail: res => { console.log(res) }
    })
    
  },


  startAction: function (e) {
    this.setData({
      num_Method1:[0,0,0,0],
      num_Method2:[0,0,0,0]
    })
   wx.showToast({
     title: '注意！返回上一页面前，务必先点击“终止识别”按钮！',
     duration:3000,
     icon:"none"
   })
    
    wx.startAccelerometer({
      interval: 'game',
      success: res => { console.log("acc调用成功"); },
      fail: res => { console.log(res) }
    });
    wx.startGyroscope({
      interval: 'game',
      success: res => { console.log("gry调用成功"); },
      fail: res => { console.log(res) }
    })
   var _this = this
    _this.setData({ isReading: true})
  var time = 0;
  let accXs = [];
  let accYs = [];
  let accZs = [];
  let rgXs = [];
  let rgYs = [];
  let rgZs = [];

  let accYsAll = [];

  let activity= [];
    myaudioStart.play()

     _this.setData({ startTime: new Date().getTime()})

     wx.onAccelerometerChange(function (res) {
     
      accXs.push(res.x)
      accYs.push(res.y)
      accZs.push(res.z)
      



    } )
  wx.onGyroscopeChange(function (res) {
    
      rgXs.push(res.x)
      rgYs.push(res.y)
      rgZs.push(res.z)

  })
  this.data.timer = setInterval(function () {
    let mid_time = new Date().getTime();

     // console.log(res.x, res.y, res.z, mid_time )
     let timeStep = (mid_time - _this.data.startTime) / 1000
     _this.setData({ value: parseInt(timeStep *1.67), displayValue: parseInt(timeStep)});
    if(timeStep < 60.5){

  
  //发送请求
  
  wx.request({
    url: 'https://www.inifyy.cn:8000/',
    method: 'POST',
    
    data: {
      accx:accXs,
      accy:accYs,
      accz:accZs,
      gryx:rgXs,
      gryy:rgYs,
      gryz:rgZs,
      system:1
      
    },
    success: function (res) {
      var num1 = "num_Method1[" + 0 + "]";
      var num2 = "num_Method1[" + 1 + "]";
      var num3 = "num_Method1[" + 2 + "]";
      var num4 = "num_Method1[" + 3 + "]";
      var resData = res.data;
      if (resData != "") {
        activity.push(resData)
        if(resData == '5'){
          _this.setData({
            action: '站立'
          })
        }
        if(resData == '1'){
        _this.setData({
          action: '徒手侧平举',
          [num1] :_this.data.num_Method1[0] +1  
      })
    }
        if(resData == '2'){
        _this.setData({
          action: '前后交叉小跑',
          [num2] :_this.data.num_Method1[1] +1  
        })
      }
        if(resData == '3'){
        _this.setData({
          action: '开合跳',
          [num3] :_this.data.num_Method1[2] +1  
        })
      }
      if(resData == '4'){
        _this.setData({
          action: '半蹲',
          [num4] :_this.data.num_Method1[3] +1  
        })
      }
        //获取数据后重新开启定时器发送请求


      } 
    }
   
  })
  accYsAll = accYsAll.concat(accYs)
  accXs = [];
  accYs = [];
  accZs = [];
  rgXs = [];
  rgYs = [];
  rgZs = [];
  _this.setData({ accYsAll:accYsAll ,activity:activity});
}
  else{
    wx.offAccelerometerChange()
    wx.offGyroscopeChange()
    _this.setData({ value: 100, displayValue: 60,accYsAll:accYsAll ,activity:activity});
    _this.stopAction()
    accYsAll = []
    activity = []
  }
}, 1200);

this.data.timer1 = setInterval(function () {
  let mid_time = new Date().getTime();

     // console.log(res.x, res.y, res.z, mid_time )
     let timeStep = (mid_time - _this.data.startTime) / 1000
     _this.setData({ value: parseInt(timeStep *1.67), displayValue: parseInt(timeStep)});
  if(timeStep < 60.5){
    let action = _this.data.action
    if(action == '站立'){

      myaudioAction0.play()
  
    }
  if(action == '徒手侧平举'){

    myaudioAction1.play()

  }
  if(action == '前后交叉小跑'){

    myaudioAction2.play()
  }
  if(action == '开合跳'){

    myaudioAction3.play()
    console.log('开始播放2')
  }
  if(action == '半蹲'){

    myaudioAction4.play()
  }
}
},3600);

  
},


  stopAction: function () {
    let _this = this
    console.log(_this.data.num)
    _this.setData({ isReading: false,displayValue:0,time:0 ,action:''})
    clearInterval(_this.data.timer)
    clearInterval(_this.data.timer1)
    wx.stopAccelerometer({
      success: res => {
        console.log("结束")   
      }
    }) 
    wx.stopGyroscope({
      success: res => {
        console.log("结束")
      }
    }) 
    myaudioEnd.play()
    setTimeout(function () {
      myaudioEnd.stop()
      },1300)

    wx.request({
      url: 'https://www.inifyy.cn:8000/count',
      method: 'POST',
      
      data: {

        accyAll:_this.data.accYsAll,
        activity:_this.data.activity,
        system:1
        
      },
      success: function (res) {
        var resData = res.data;
        var num1 = "num_Method2[" + 0 + "]";
        var num2 = "num_Method2[" + 1 + "]";
        var num3 = "num_Method2[" + 2 + "]";
        var num4 = "num_Method2[" + 3 + "]";
        if (resData != "") {
          var count = resData.split(',');
          var count1 =count[ 0];
          var count2 = count[1];
          var count3 = count[2];
          var count4 = count[3];

          _this.setData({
            [num1] : count1,
            [num2] : count2,
            [num3] : count3,
            [num4] : count4,
          })
          console.log(_this.data.num)
        }

          //获取数据后重新开启定时器发送请求
  
  
        } 
      })
    
    
    
  },

  onHide: function () {
    this.stopAction()
    myaudioStart.stop()
    myaudioEnd.stop()
    myaudioAction0.stop()
    myaudioAction1.stop()
    myaudioAction2.stop()
    myaudioAction3.stop()
    myaudioAction4.stop()
  },
  onUnload:function(){
    this.stopAction()
    myaudioStart.stop()
    myaudioEnd.stop()
    myaudioAction0.stop()
    myaudioAction1.stop()
    myaudioAction2.stop()
    myaudioAction3.stop()
    myaudioAction4.stop()
  }

  /**
   * 生命周期函数--监听页面卸载
   */

})
