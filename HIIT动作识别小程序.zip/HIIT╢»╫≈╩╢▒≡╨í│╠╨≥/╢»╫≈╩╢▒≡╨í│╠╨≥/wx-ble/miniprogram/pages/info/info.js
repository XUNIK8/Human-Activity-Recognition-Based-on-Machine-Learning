

// pages/info/info.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    text:"\n1. 本小程序用于采集使用者做HIIT动作时的手机六轴数据，将数据传输至云服务器上进行处理，并投放至机器学习算法中进行动作识别，最终将用户正在进行的动作信息反馈至小程序页面。\n\n 2. 本小程序仅选取四组HIIT动作进行，动作示范将在后续页面给予显示。使用过程中请左手持握手机、手机背面贴掌心、机身正置（与日常使用时握法一致)，请参考下图。\n\n 3. 本小程序暂仅用于开发者的实验设计期末项目测试，若有问题请联系QQ：986927662 ——SDUWH XHJ。\n",
    show: true,
    activeName: ['1'],
    showSystem:false,
    actions: [
      {
        name: '苹果（iOS）',

      },
      {
        name: '安卓（Android）',

      }]
  },

  showPopup() {
    this.setData({ show: true });
  },

  onClose1:function() {
    this.setData({ show: false });
  },

  toHome(){
    if(this.data.system == '苹果（iOS）'){
    wx.navigateTo({
      url: '../home/home',
    })
  }
    else if(this.data.system == '安卓（Android）'){
      wx.navigateTo({
        url: '../home_Android/home_Android',
      })
    }
    else{
        wx.showToast({
          title: '请先选择设备！',
          icon:'none'
        })
    }
  },
  onClose() {
    this.setData({ showSystem: false });
  },

  onSelect(event) {
    console.log(event.detail);
    this.setData({
      system:event.detail.name
    })
    wx.showToast({
      title: '选择成功',
    })
  },
  selectSystem(){
    this.setData({
      showSystem:true
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})