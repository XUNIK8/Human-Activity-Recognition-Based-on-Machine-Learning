// pages/home_Android/home_Android.js
import Dialog from '@vant/weapp/dialog/dialog';
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  
  _BLE: function() {
    wx.navigateTo({        /*跳转界面 */
      url: '../conn/conn',
    })
  },
  _ACC: function() {
    Dialog.confirm({
      title: '注意',
      message: '本功能用于后台数据收集，非开发者请勿随意操作。请与开发者联系，是否确认进入。',
    })
      .then(() => {
        // on confirm
        wx.navigateTo({
      url: '../acc_Android/acc_Android',
    })
      })
      .catch(() => {
        // on cancel
      });
  },
  _USE: function() {
    wx.navigateTo({        /*跳转界面 */
      url: '../use_Android/use_Android',
    })
  },
})