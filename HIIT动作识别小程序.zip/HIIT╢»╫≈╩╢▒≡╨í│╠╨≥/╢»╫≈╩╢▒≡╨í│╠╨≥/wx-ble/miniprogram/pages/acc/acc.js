// pages/acc/acc.js
const app = getApp()
//获取数据库引用
const db = wx.cloud.database({ env: 'test-krasj' });       /**引用数据库 */
const actionA = db.collection('actionA')
const actionB = db.collection('actionB') 
const actionC = db.collection('actionC') 
const actionD = db.collection('actionD')       /**引用数据库 */
Page({

  /**
   * 页面的初始数据
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    text:['徒手侧平举','前后交叉小跑','开合跳','半蹲'],
    value: 0,
    accelerometerX: null,
    accelerometerY: null,
    accelerometerZ: null,
    gyroscopeX: null,
    gyroscopeY: null,
    gyroscopeZ: null,
    accXs: [],
    accYs: [],
    accZs: [],
    rgXs: [],
    rgYs: [],
    rgZs: [],
    timeSs: [],
    startTime: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("获取加速度计数据");
    wx.startAccelerometer({
      interval: 'game',
      success: res => { console.log("调用成功"); },
      fail: res => { console.log(res) }
    });
    wx.startGyroscope({
      interval: 'game',
      success: res => { console.log("调用成功"); },
      fail: res => { console.log(res) }
    })
  },

  startAction: function (e) {
    this.setData({accXs: [], accYs: [], accZs: [], rgXs: [], rgYs: [], rgZs: [], timeSs: [] })
    wx.startAccelerometer({
      interval: 'game',
      success: res => { console.log("调用成功"); },
      fail: res => { console.log(res) }
    });
    wx.startGyroscope({
      interval: 'game',
      success: res => { console.log("调用成功"); },
      fail: res => { console.log(res) }
    })
    this.setData({ startTime: new Date().getTime()})
    let _this = this;
    _this.setData({ isReading: true })
    let accXs = [];
    let accYs = [];
    let accZs = [];
    let rgXs = [];
    let rgYs = [];
    let rgZs = [];
    let timeSs = [];
    // 监听加速度数据

    wx.onAccelerometerChange(function (res) {
      let mid_time = new Date().getTime();
      console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
      // console.log(res.x, res.y, res.z, mid_time )
      let timeStep = (mid_time - _this.data.startTime) / 1000
      _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep)});
      if (timeStep < 10) {
        // console.log("timeStep < 10")
        accXs.push(res.x)
        accYs.push(res.y)
        accZs.push(res.z)
        timeSs.push(mid_time)
        _this.setData({                         /**页面显示 */
          accelerometerX: parseFloat(res.x.toFixed(5)),
          accelerometerY: parseFloat(res.y.toFixed(5)),
          accelerometerZ: parseFloat(res.z.toFixed(5))
        })
      } 
      if (timeStep >= 10) {
        // console.log("timeStep = 10")
        _this.setData({ value: 100, displayValue: 10});
        _this.stopAction();
        // console.log("end-time: ", Date.now())
        _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, timeSs: timeSs })
        wx.offAccelerometerChange()
   
        return;
      }
    })
    wx.onGyroscopeChange(function (res) {
      let mid_time = new Date().getTime();
      console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
      // console.log(res.x, res.y, res.z, mid_time )
      let timeStep = (mid_time - _this.data.startTime) / 1000
      _this.setData({ value: parseInt(timeStep *10), displayValue: parseInt(timeStep)});
      if (timeStep < 10) {
        // console.log("timeStep < 10")
        rgXs.push(res.x)
        rgYs.push(res.y)
        rgZs.push(res.z)
        timeSs.push(mid_time)
        _this.setData({                         /**页面显示 */
          gyroscopeX: parseFloat(res.x.toFixed(5)),
          gyroscopeY: parseFloat(res.y.toFixed(5)),
          gyroscopeZ: parseFloat(res.z.toFixed(5))
        })
      } 
      if (timeStep >= 10) {
        // console.log("timeStep = 10")
        _this.setData({ value: 100, displayValue: 10});
        _this.stopAction();
        // console.log("end-time: ", Date.now())
        _this.setData({ rgXs: rgXs, rgYs: rgYs, rgZs: rgZs, timeSs: timeSs })
        wx.offGyroscopeChange()

        
        return;
      }
    })
  },
  
  stopAction: function () {
    let _this = this
    this.setData({ isReading: false })
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取")
        _this.setData({ accelerometerX: null, accelerometerY: null, accelerometerZ: null, activity: null })
      }
    }) 
    wx.stopGyroscope({
      success: res => {
        console.log("停止读取")
        _this.setData({ gyroscopeX: null, gyroscopeY: null, gyroscopeZ: null, activity: null })
      }
    })
    
  },
  saveA() {                   /**存储到数据库 */
    console.log("save...")
    let accXs = this.data.accXs, accYs = this.data.accYs, accZs = this.data.accZs, rgXs = this.data.rgXs, rgYs = this.data.rgYs, rgZs = this.data.rgZs,timeSs = this.data.timeSs;
    actionA.add({
      data: { activity:1,accx: accXs, accy: accYs, accz: accZs,gryx: rgXs, gryy: rgYs, gryz: rgZs, time: timeSs}
    })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
        
      })
      .catch(res => { console.log("保存失败") })

  },
  saveB() {                   /**存储到数据库 */
    console.log("save...")
    let accXs = this.data.accXs, accYs = this.data.accYs, accZs = this.data.accZs, rgXs = this.data.rgXs, rgYs = this.data.rgYs, rgZs = this.data.rgZs,timeSs = this.data.timeSs;
    actionB.add({
      data: { activity:0,accx: accXs, accy: accYs, accz: accZs,gryx: rgXs, gryy: rgYs, gryz: rgZs, time: timeSs}
    })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
       
      })
      .catch(res => { console.log("保存失败") })

  },
  saveC() {                   /**存储到数据库 */
    console.log("save...")
    let accXs = this.data.accXs, accYs = this.data.accYs, accZs = this.data.accZs, rgXs = this.data.rgXs, rgYs = this.data.rgYs, rgZs = this.data.rgZs,timeSs = this.data.timeSs;
    actionC.add({
      data: { activity:3,accx: accXs, accy: accYs, accz: accZs,gryx: rgXs, gryy: rgYs, gryz: rgZs, time: timeSs}
    })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
        
      })
      .catch(res => { console.log("保存失败") })

  },
  saveD() {                   /**存储到数据库 */
    console.log("save...")
    let accXs = this.data.accXs, accYs = this.data.accYs, accZs = this.data.accZs, rgXs = this.data.rgXs, rgYs = this.data.rgYs, rgZs = this.data.rgZs,timeSs = this.data.timeSs;
    actionD.add({
      data: { activity:4,accx: accXs, accy: accYs, accz: accZs,gryx: rgXs, gryy: rgYs, gryz: rgZs, time: timeSs}
    })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
        
      })
      .catch(res => { console.log("保存失败") })
      
  },

  takePhoto: function() {
    let _this = this
    wx.chooseImage({             /**选图片 */
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['camera'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        const tempFilePaths = res.tempFilePaths    /**图片临时路径 */
        _this.setData({
          tmpImg: tempFilePaths,                   /**把临时路径存储 */
        })
      }
    })
  },

  saveImg: function() {
    let filePath = this.data.tmpImg[0];           /**调临时路径 */
    let suffix = /\.[^\.]+$/.exec(filePath)[0];
    wx.cloud.uploadFile({                         /*上传文件 */
      cloudPath: "Camera/" + new Date().getTime() + suffix,
      filePath: filePath,
      config: { env: 'test-krasj' }
    }).then(res => {
      console.log(res);
      this.setData({ fileIDs: res.fileID, tmpImg: null});
      wx.showToast({
        title: '保存成功',
      })
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})